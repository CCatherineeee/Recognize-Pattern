import pandas as pd 
import math
import scipy.stats as stats
import numpy as np

def independent_t_test(data1, data2):
    """
    执行独立样本 t 检验

    参数：
    - data1: 第一组数据
    - data2: 第二组数据

    返回值：
    - t_stat: t 统计量
    - df: 自由度
    """

    # 计算均值
    mean1 = sum(data1) / len(data1)
    mean2 = sum(data2) / len(data2)

    # 计算标准差
    std1 = (sum((x - mean1) ** 2 for x in data1) / len(data1)) ** 0.5
    std2 = (sum((x - mean2) ** 2 for x in data2) / len(data2)) ** 0.5

    df = len(data1) + len(data2) - 2

    # 计算 t 统计量
    t_stat = (mean1 - mean2) / ((std1**2 / len(data1)) + (std2**2 / len(data2))) ** 0.5
    return t_stat, df

def independent_k_test(observed_data1, observed_data2, expected_data1, expected_data2):
    """
        执行 Chi-Square Probabilities 检验

        参数：
        - observed_data1: 第一组数据频率
        - observed_data2: 第二组数据频率
        - expected_data1: 期望第二组数据频率
        - expected_data2: 期望第二组数据频率

        返回值：
        - chi_squared_stat: chi_squared_stat 统计量
        - df: 自由度
        """
    # 构建列联表
    observed_data = np.array([observed_data1, observed_data2])
    expected_data = np.array([expected_data1, expected_data2])

    df = (observed_data.shape[0] - 1) * (2 - 1)

    # 计算卡方统计量
    chi_squared_stat = np.sum((observed_data - expected_data)**2 / expected_data)
    return chi_squared_stat, df


laughter = pd.read_csv('./laughter-corpus.csv') # dataframe
# dataframe.loc[]

# 1
num_female = laughter.loc[laughter['Gender']=='Female']
num_male = laughter.loc[laughter['Gender']=='Male']

# 观察到的频数
observed_female = len(num_female)
observed_male = len(num_male)
 
# 期望频数
expected_female = 63 / 120 * (len(num_male) + len(num_female))
expected_male = 57 / 120 * (len(num_male) + len(num_female))

# 执行 chi-square 检验
chi_squared_stat, df = independent_k_test(observed_female, observed_male, expected_female, expected_male)

print(chi_squared_stat)
if chi_squared_stat > 3.84: # p < 0.05
    reject_null = True
    print("Reject null hypothesis: The number of laughter events differs between Male and Female.")
    print("Confidence level: 95%")
else:
    reject_null = False
    print("Accepet null hypothesis: The number of laughter events are same between Male and Female.")
    print("Confidence level: 95%")

# 2
durations_caller = laughter.loc[laughter['Role']=='Caller']
durations_receiver = laughter.loc[laughter['Role']=='Receiver']

# 观察到的频数
observed_caller = len(durations_caller)
observed_receiver= len(durations_receiver)

# 期望频数
expected_caller = 60 / 120 * (len(durations_caller) + len(durations_receiver))
expected_receiver = 60 / 120 * (len(durations_caller) + len(durations_receiver))

# 执行 chi-square 检验
chi_squared_stat, df = independent_k_test(observed_caller, observed_receiver, expected_caller, expected_receiver)
if chi_squared_stat > 3.84: # p < 0.05
    reject_null = True
    print("Reject null hypothesis: The number of laughter events differs between Callers and Receivers.")
    print("Confidence level: Not statistically significant")
else:
    reject_null = False
    print("Confidence level: 95%")

# 3
durations_female = laughter.loc[laughter['Gender']=='Female']['Duration']
durations_male = laughter.loc[laughter['Gender']=='Male']['Duration']

# 执行 t 检验
t_stat, df = independent_t_test(durations_female, durations_male)
if t_stat > 1.960: # p < 0.05
    reject_null_gender = True
    print("Reject null hypothesis: The duration of laughter events differs between Male Callers and Male Receivers.")
    print("Confidence level: 95%")
else:
    reject_null_gender = False
    print("Confidence level: 95%")


# 4
durations_caller = laughter.loc[laughter['Role']=='Caller']['Duration'].astype(float)
durations_receiver = laughter.loc[laughter['Role']=='Receiver']['Duration'].astype(float)
# 执行 t 检验
t_stat, df = independent_t_test(durations_caller, durations_receiver)
if t_stat > 1.960: # p < 0.05
    reject_null_call = True
    print("Reject null hypothesis: The duration of laughter events differs between Callers and Receivers.")
    print("Confidence level: 95%")
else:
    reject_null_call = False
    print("Confidence level: 95%")

